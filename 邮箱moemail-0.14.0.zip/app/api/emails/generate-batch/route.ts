import { NextResponse } from "next/server"
import { nanoid } from "nanoid"
import { createDb } from "@/lib/db"
import { emails } from "@/lib/schema"
import { eq, and, gt, sql } from "drizzle-orm"
import { EXPIRY_OPTIONS } from "@/types/email"
import { EMAIL_CONFIG } from "@/config"
import { getRequestContext } from "@cloudflare/next-on-pages"
import { getUserId } from "@/lib/apiKey"
import { getUserRole } from "@/lib/auth"
import { ROLES } from "@/lib/permissions"

export const runtime = "edge"

export async function POST(request: Request) {
  const db = createDb()
  const env = getRequestContext().env

  const userId = await getUserId()
  const userRole = await getUserRole(userId!)

  try {
    const { count, expiryTime, domain } = await request.json<{ 
      count: number
      expiryTime: number
      domain: string
    }>()

    // 验证批量数量
    if (!count || count < 1 || count > 50) {
      return NextResponse.json(
        { error: "批量创建数量必须在 1-50 之间" },
        { status: 400 }
      )
    }

    // 验证过期时间
    if (!EXPIRY_OPTIONS.some(option => option.value === expiryTime)) {
      return NextResponse.json(
        { error: "无效的过期时间" },
        { status: 400 }
      )
    }

    // 验证域名
    const domainString = await env.SITE_CONFIG.get("EMAIL_DOMAINS")
    const domains = domainString ? domainString.split(',') : ["moemail.app"]

    if (!domains || !domains.includes(domain)) {
      return NextResponse.json(
        { error: "无效的域名" },
        { status: 400 }
      )
    }

    // 检查邮箱数量限制
    if (userRole !== ROLES.EMPEROR) {
      const maxEmails = await env.SITE_CONFIG.get("MAX_EMAILS") || EMAIL_CONFIG.MAX_ACTIVE_EMAILS.toString()
      const activeEmailsCount = await db
        .select({ count: sql<number>`count(*)` })
        .from(emails)
        .where(
          and(
            eq(emails.userId, userId!),
            gt(emails.expiresAt, new Date())
          )
        )
      
      const currentCount = Number(activeEmailsCount[0].count)
      const maxCount = Number(maxEmails)
      
      if (currentCount + count > maxCount) {
        return NextResponse.json(
          { error: `批量创建将超过最大邮箱数量限制 (${maxCount})，当前已有 ${currentCount} 个邮箱` },
          { status: 403 }
        )
      }
    }

    const now = new Date()
    const expires = expiryTime === 0 
      ? new Date('9999-01-01T00:00:00.000Z')
      : new Date(now.getTime() + expiryTime)

    // 生成唯一的邮箱地址
    const emailsToCreate: (typeof emails.$inferInsert)[] = []
    const generatedNames = new Set<string>()
    
    for (let i = 0; i < count; i++) {
      let attempts = 0
      let name = ""
      let address = ""
      let isUnique = false

      // 尝试生成唯一的邮箱地址，最多尝试 10 次
      while (!isUnique && attempts < 10) {
        name = nanoid(8)
        address = `${name}@${domain}`
        
        // 检查是否在本次批量中重复
        if (generatedNames.has(address.toLowerCase())) {
          attempts++
          continue
        }

        // 检查数据库中是否存在
        const existingEmail = await db.query.emails.findFirst({
          where: eq(sql`LOWER(${emails.address})`, address.toLowerCase())
        })

        if (!existingEmail) {
          isUnique = true
          generatedNames.add(address.toLowerCase())
        }
        
        attempts++
      }

      if (!isUnique) {
        return NextResponse.json(
          { error: `生成唯一邮箱地址失败，请稍后重试` },
          { status: 500 }
        )
      }

      emailsToCreate.push({
        address,
        createdAt: now,
        expiresAt: expires,
        userId: userId!
      })
    }

    // 批量插入邮箱
    const result = await db.insert(emails)
      .values(emailsToCreate)
      .returning({ id: emails.id, address: emails.address })
    
    return NextResponse.json({ 
      created: result.length,
      emails: result.map(r => r.address)
    })
  } catch (error) {
    console.error('Failed to batch generate emails:', error)
    return NextResponse.json(
      { error: "批量创建邮箱失败" },
      { status: 500 }
    )
  }
}

