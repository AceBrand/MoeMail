import { GET, POST } from "@/lib/auth"

export { GET, POST }

export const runtime = 'edge'