"use client"

import { useEffect, useState } from "react"
import { useTranslations } from "next-intl"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Copy, Plus, RefreshCw } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { nanoid } from "nanoid"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { EXPIRY_OPTIONS } from "@/types/email"
import { useCopy } from "@/hooks/use-copy"
import { useConfig } from "@/hooks/use-config"

interface CreateDialogProps {
  onEmailCreated: () => void
}

export function CreateDialog({ onEmailCreated }: CreateDialogProps) {
  const { config } = useConfig()
  const t = useTranslations("emails.create")
  const tList = useTranslations("emails.list")
  const tCommon = useTranslations("common.actions")
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [emailName, setEmailName] = useState("")
  const [currentDomain, setCurrentDomain] = useState("")
  const [expiryTime, setExpiryTime] = useState(EXPIRY_OPTIONS[1].value.toString())
  const [batchCount, setBatchCount] = useState("5")
  const { toast } = useToast()
  const { copyToClipboard } = useCopy()

  const generateRandomName = () => setEmailName(nanoid(8))

  const copyEmailAddress = () => {
    copyToClipboard(`${emailName}@${currentDomain}`)
  }

  const createEmail = async () => {
    if (!emailName.trim()) {
      toast({
        title: tList("error"),
        description: t("namePlaceholder"),
        variant: "destructive"
      })
      return
    }

    setLoading(true)
    try {
      const response = await fetch("/api/emails/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: emailName,
          domain: currentDomain,
          expiryTime: parseInt(expiryTime)
        })
      })

      if (!response.ok) {
        const data = await response.json()
        toast({
          title: tList("error"),
          description: (data as { error: string }).error,
          variant: "destructive"
        })
        return
      }

      toast({
        title: tList("success"),
        description: t("success")
      })
      onEmailCreated()
      setOpen(false)
      setEmailName("")
    } catch {
      toast({
        title: tList("error"),
        description: t("failed"),
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  const createBatchEmails = async () => {
    const count = parseInt(batchCount)
    if (isNaN(count) || count < 1 || count > 50) {
      toast({
        title: tList("error"),
        description: t("batchCountError"),
        variant: "destructive"
      })
      return
    }

    setLoading(true)
    try {
      const response = await fetch("/api/emails/generate-batch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          count,
          domain: currentDomain,
          expiryTime: parseInt(expiryTime)
        })
      })

      if (!response.ok) {
        const data = await response.json()
        toast({
          title: tList("error"),
          description: (data as { error: string }).error,
          variant: "destructive"
        })
        return
      }

      const result = await response.json()
      toast({
        title: tList("success"),
        description: t("batchSuccess", { count: result.created })
      })
      onEmailCreated()
      setOpen(false)
    } catch {
      toast({
        title: tList("error"),
        description: t("batchFailed"),
        variant: "destructive"
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if ((config?.emailDomainsArray?.length ?? 0) > 0) {
      setCurrentDomain(config?.emailDomainsArray[0] ?? "")
    }
  }, [config])

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2">
          <Plus className="w-4 h-4" />
          {t("title")}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{t("title")}</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="single" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="single">{t("singleCreate")}</TabsTrigger>
            <TabsTrigger value="batch">{t("batchCreate")}</TabsTrigger>
          </TabsList>

          <TabsContent value="single" className="space-y-4 mt-4">
            <div className="flex gap-2">
              <Input
                value={emailName}
                onChange={(e) => setEmailName(e.target.value)}
                placeholder={t("namePlaceholder")}
                className="flex-1"
              />
              {(config?.emailDomainsArray?.length ?? 0) > 1 && (
                <Select value={currentDomain} onValueChange={setCurrentDomain}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {config?.emailDomainsArray?.map(d => (
                      <SelectItem key={d} value={d}>@{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
              <Button
                variant="outline"
                size="icon"
                onClick={generateRandomName}
                type="button"
              >
                <RefreshCw className="w-4 h-4" />
              </Button>
            </div>

            <div className="flex items-center gap-4">
              <Label className="shrink-0 text-muted-foreground">{t("expiryTime")}</Label>
              <RadioGroup
                value={expiryTime}
                onValueChange={setExpiryTime}
                className="flex gap-6"
              >
                {EXPIRY_OPTIONS.map((option, index) => {
                  const labels = [t("oneHour"), t("oneDay"), t("threeDays"), t("oneMonth"), t("permanent")]
                  return (
                    <div key={option.value} className="flex items-center gap-2">
                      <RadioGroupItem value={option.value.toString()} id={option.value.toString()} />
                      <Label htmlFor={option.value.toString()} className="cursor-pointer text-sm">
                        {labels[index]}
                      </Label>
                    </div>
                  )
                })}
              </RadioGroup>
            </div>

            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span className="shrink-0">{t("domain")}:</span>
              {emailName ? (
                <div className="flex items-center gap-2 min-w-0">
                  <span className="truncate">{`${emailName}@${currentDomain}`}</span>
                  <div
                    className="shrink-0 cursor-pointer hover:text-primary transition-colors"
                    onClick={copyEmailAddress}
                  >
                    <Copy className="size-4" />
                  </div>
                </div>
              ) : (
                <span className="text-gray-400">...</span>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setOpen(false)} disabled={loading}>
                {tCommon("cancel")}
              </Button>
              <Button onClick={createEmail} disabled={loading}>
                {loading ? t("creating") : t("create")}
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="batch" className="space-y-4 mt-4">
            <div className="flex gap-2 items-center">
              <Label className="shrink-0 text-muted-foreground">{t("batchCount")}</Label>
              <Input
                type="number"
                value={batchCount}
                onChange={(e) => setBatchCount(e.target.value)}
                placeholder={t("batchCountPlaceholder")}
                className="w-32"
                min="1"
                max="50"
              />
              <span className="text-sm text-muted-foreground">{t("batchCountHint")}</span>
            </div>

            {(config?.emailDomainsArray?.length ?? 0) > 1 && (
              <div className="flex gap-2 items-center">
                <Label className="shrink-0 text-muted-foreground">{t("domain")}</Label>
                <Select value={currentDomain} onValueChange={setCurrentDomain}>
                  <SelectTrigger className="w-[200px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {config?.emailDomainsArray?.map(d => (
                      <SelectItem key={d} value={d}>@{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="flex items-center gap-4">
              <Label className="shrink-0 text-muted-foreground">{t("expiryTime")}</Label>
              <RadioGroup
                value={expiryTime}
                onValueChange={setExpiryTime}
                className="flex gap-6"
              >
                {EXPIRY_OPTIONS.map((option, index) => {
                  const labels = [t("oneHour"), t("oneDay"), t("threeDays"), t("oneMonth"), t("permanent")]
                  return (
                    <div key={option.value} className="flex items-center gap-2">
                      <RadioGroupItem value={option.value.toString()} id={`batch-${option.value.toString()}`} />
                      <Label htmlFor={`batch-${option.value.toString()}`} className="cursor-pointer text-sm">
                        {labels[index]}
                      </Label>
                    </div>
                  )
                })}
              </RadioGroup>
            </div>

            <div className="bg-muted/50 p-3 rounded-md text-sm text-muted-foreground">
              {t("batchNote")}
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setOpen(false)} disabled={loading}>
                {tCommon("cancel")}
              </Button>
              <Button onClick={createBatchEmails} disabled={loading}>
                {loading ? t("creating") : t("batchCreateButton")}
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
} 