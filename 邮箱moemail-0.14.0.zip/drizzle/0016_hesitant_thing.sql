ALTER TABLE `email_share` DROP COLUMN `enabled`;--> statement-breakpoint
ALTER TABLE `message_share` DROP COLUMN `enabled`;